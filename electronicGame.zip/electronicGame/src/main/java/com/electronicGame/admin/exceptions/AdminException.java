package com.electronicGame.admin.exceptions;

public class AdminException extends Exception{

}
