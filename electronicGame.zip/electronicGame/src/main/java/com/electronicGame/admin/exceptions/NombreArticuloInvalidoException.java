package com.electronicGame.admin.exceptions;

public class NombreArticuloInvalidoException extends AdminException {

}
