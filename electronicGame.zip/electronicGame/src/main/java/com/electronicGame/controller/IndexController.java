package com.electronicGame.controller;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.electronicGame.admin.exceptions.AdminException;
import com.electronicGame.business.IServicioIndex;
import com.electronicGame.business.ServicioHeader;
import com.electronicGame.entities.Articulo;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/")
public class IndexController {
	public static final Logger log = LoggerFactory.getLogger(BuscadorArticuloController.class);
	
	@Autowired
	IServicioIndex servicio;
	@Autowired
	private ServicioHeader servicioHeader;
	
	@GetMapping
	public String buscarArticulo(Model model,HttpSession session) throws AdminException {
		log.info("[Indice]");
		log.debug("[Indice]");
		
		//Metemos las secciones en seession
		 List<String> secciones = servicioHeader.obtenerSecciones();
		 session.setAttribute("secciones", secciones);
		
		List<Articulo> valorados = servicio.mejorValorados();
		
		
		// Ordenar la lista por mediaValoraciones en orden descendente
	    //valorados.sort(Comparator.comparingDouble(Articulo::getMediaValoraciones).reversed());
		//model.addAttribute("valorados", valorados);
	    
		// Ordenar la lista por mediaValoraciones en orden descendente y limitar a 5
	    List<Articulo> topValorados = valorados.stream()
	            .sorted(Comparator.comparingDouble(Articulo::getMediaValoraciones).reversed())
	            .limit(5)
	            .collect(Collectors.toList());

	    model.addAttribute("valorados", topValorados);
		

		
		
		return "index";
	}
	
	
}
